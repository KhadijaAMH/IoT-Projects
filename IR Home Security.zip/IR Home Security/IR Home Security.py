#Home Security System
#Program to click  picture when IR is interrupted using webcam
#THen mail the pic to the Email Address set
#Author:Khadija AMH (VIMAN's Group) Date: 25/07/2018


import time
import subprocess
import RPi.GPIO as GPIO

GPIO.setmode(GPIO.BCM)
GPIO.setup(21,GPIO.IN)

while True:
    if(GPIO.input(21)==0):
        #To take Picture in case of Interruption
        subprocess.Popen("sudo fswebcam in.jpg",shell=True)
        #TO execute mail program to send the mail
        subprocess.Popen("python mail1.py",shell=True)
        time.sleep(2)
        


#Subprocess ==== Automatic Terminal Execution (I think -DJ)
        
